"""
DevRel Scraper package for collecting Developer Relations resources.
"""
from .devrel_scraper import DevRelScraper

__all__ = ['DevRelScraper']
