import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

class DevRelMetricsDashboard:
    """Creates an interactive dashboard for DevRel metrics visualization."""

    def __init__(self):
        # Sample data generation for demonstration
        self.dates = pd.date_range(start='2023-01-01', end='2024-01-01', freq='M')
        self.metrics = self._generate_sample_metrics()

    def _generate_sample_metrics(self):
        """Generate sample metrics data for visualization."""
        np.random.seed(42)  # For reproducibility

        return {
            'community_growth': 1000 + np.cumsum(np.random.normal(100, 20, len(self.dates))),
            'engagement_rate': 20 + np.random.normal(0, 2, len(self.dates)),
            'content_views': 5000 + np.cumsum(np.random.normal(500, 100, len(self.dates))),
            'developer_satisfaction': 85 + np.random.normal(0, 3, len(self.dates)),
            'event_attendance': 200 + np.random.normal(20, 5, len(self.dates)),
            'github_stars': 500 + np.cumsum(np.random.normal(50, 10, len(self.dates)))
        }

    def create_dashboard(self):
        """Generate an interactive metrics dashboard."""
        # Create figure with secondary y-axis
        fig = make_subplots(
            rows=3, cols=2,
            subplot_titles=(
                'Community Growth', 'Engagement Rate (%)',
                'Content Views', 'Developer Satisfaction Score',
                'Event Attendance', 'GitHub Stars'
            ),
            vertical_spacing=0.12,
            horizontal_spacing=0.1
        )

        # Add traces for each metric
        fig.add_trace(
            go.Scatter(x=self.dates, y=self.metrics['community_growth'],
                      name="Community Members", line=dict(color="#1f77b4")),
            row=1, col=1
        )

        fig.add_trace(
            go.Scatter(x=self.dates, y=self.metrics['engagement_rate'],
                      name="Engagement Rate", line=dict(color="#ff7f0e")),
            row=1, col=2
        )

        fig.add_trace(
            go.Scatter(x=self.dates, y=self.metrics['content_views'],
                      name="Content Views", line=dict(color="#2ca02c")),
            row=2, col=1
        )

        fig.add_trace(
            go.Scatter(x=self.dates, y=self.metrics['developer_satisfaction'],
                      name="Dev Satisfaction", line=dict(color="#d62728")),
            row=2, col=2
        )

        fig.add_trace(
            go.Bar(x=self.dates, y=self.metrics['event_attendance'],
                  name="Event Attendance", marker_color="#9467bd"),
            row=3, col=1
        )

        fig.add_trace(
            go.Scatter(x=self.dates, y=self.metrics['github_stars'],
                      name="GitHub Stars", line=dict(color="#8c564b")),
            row=3, col=2
        )

        # Update layout
        fig.update_layout(
            height=900,
            width=1200,
            title_text="DevRel Metrics Dashboard",
            showlegend=True,
            template="plotly_white",
            annotations=[
                dict(
                    text="Interactive DevRel Metrics Dashboard showing key performance indicators over time.",
                    xref="paper",
                    yref="paper",
                    x=0,
                    y=1.1,
                    showarrow=False,
                    font=dict(size=12)
                )
            ]
        )

        # Update axes labels and format
        fig.update_xaxes(title_text="Date", gridcolor='lightgray')
        fig.update_yaxes(title_text="Count", gridcolor='lightgray')

        # Add hover templates
        for i in fig.data:
            i.hovertemplate = "%{y:,.0f}<br>Date: %{x|%B %Y}<extra></extra>"

        return fig

    def save_dashboard(self, output_file='metrics_dashboard.html'):
        """Save the metrics dashboard to HTML and PNG files."""
        try:
            fig = self.create_dashboard()

            # Save HTML version
            fig.write_html(output_file, include_plotlyjs=True, full_html=True)

            # Save PNG version
            png_file = os.path.splitext(output_file)[0] + '.png'
            fig.write_image(
                png_file,
                width=1200,
                height=900,
                scale=2  # Higher resolution
            )

            return True
        except Exception as e:
            print(f"Error saving dashboard: {e}")
            return False

def generate_metrics_dashboard(output_dir='static/visualizations'):
    """Create and save the metrics dashboard."""
    dashboard = DevRelMetricsDashboard()
    dashboard.save_dashboard(os.path.join(output_dir, 'metrics_dashboard.html'))

def main():
    """Create and save the metrics dashboard."""
    generate_metrics_dashboard()

if __name__ == '__main__':
    main()
