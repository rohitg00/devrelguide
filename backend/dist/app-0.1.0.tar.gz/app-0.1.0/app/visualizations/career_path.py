import plotly.graph_objects as go
import json
import os

class CareerPathVisualizer:
    """Creates an interactive career path visualization for DevRel roles."""

    def __init__(self):
        self.career_paths = {
            "Entry Level": {
                "roles": ["Technical Writer", "Developer Support", "Community Moderator"],
                "skills": ["Technical Writing", "Basic Programming", "Communication"],
                "next": ["Mid Level"]
            },
            "Mid Level": {
                "roles": ["Developer Advocate", "Technical Community Manager", "Content Developer"],
                "skills": ["Public Speaking", "Content Creation", "Technical Demos"],
                "next": ["Senior Level"]
            },
            "Senior Level": {
                "roles": ["Senior Developer Advocate", "DevRel Program Manager", "Developer Marketing Manager"],
                "skills": ["Strategy Development", "Team Leadership", "Program Management"],
                "next": ["Leadership"]
            },
            "Leadership": {
                "roles": ["Head of Developer Relations", "Director of Developer Experience", "VP of Developer Ecosystem"],
                "skills": ["Executive Communication", "Strategy", "Business Development"],
                "next": []
            }
        }

    def create_career_path_diagram(self):
        """Generate an interactive career path diagram using Plotly."""
        # Create nodes and edges for the diagram
        nodes = []
        edge_x = []
        edge_y = []

        # Position calculations
        levels = list(self.career_paths.keys())
        level_x = {level: i * 300 for i, level in enumerate(levels)}

        # Create nodes
        for level, details in self.career_paths.items():
            x = level_x[level]
            for i, role in enumerate(details["roles"]):
                y = i * 100 - (len(details["roles"]) - 1) * 50
                nodes.append({
                    "x": x,
                    "y": y,
                    "name": role,
                    "level": level,
                    "skills": details["skills"]
                })

                # Create edges to next level
                if details["next"]:
                    next_level = details["next"][0]
                    next_x = level_x[next_level]
                    for next_role in self.career_paths[next_level]["roles"]:
                        next_y = (self.career_paths[next_level]["roles"].index(next_role) * 100 -
                                (len(self.career_paths[next_level]["roles"]) - 1) * 50)
                        edge_x.extend([x, next_x, None])
                        edge_y.extend([y, next_y, None])

        # Create the figure
        fig = go.Figure()

        # Add edges
        fig.add_trace(go.Scatter(
            x=edge_x,
            y=edge_y,
            mode='lines',
            line=dict(color='rgb(210,210,210)', width=1),
            hoverinfo='none'
        ))

        # Add nodes
        fig.add_trace(go.Scatter(
            x=[node["x"] for node in nodes],
            y=[node["y"] for node in nodes],
            mode='markers+text',
            marker=dict(
                size=20,
                color='rgb(66,133,244)',
                line=dict(color='white', width=2)
            ),
            text=[node["name"] for node in nodes],
            textposition="top center",
            hovertemplate=(
                "<b>Role:</b> %{text}<br>" +
                "<b>Level:</b> %{customdata[0]}<br>" +
                "<b>Required Skills:</b><br>%{customdata[1]}<br>" +
                "<extra></extra>"
            ),
            customdata=[[node["level"], "<br>".join(node["skills"])] for node in nodes]
        ))

        # Update layout
        fig.update_layout(
            title="DevRel Career Path Progression",
            showlegend=False,
            hovermode='closest',
            margin=dict(b=20,l=5,r=5,t=40),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            plot_bgcolor='white',
            width=1200,
            height=600
        )

        return fig

    def save_diagram(self, output_file='career_path.html'):
        """Save the career path diagram to HTML and PNG files."""
        try:
            fig = self.create_career_path_diagram()

            # Save HTML version
            fig.write_html(output_file, include_plotlyjs=True, full_html=True)

            # Save PNG version
            png_file = os.path.splitext(output_file)[0] + '.png'
            fig.write_image(
                png_file,
                width=1200,
                height=800,
                scale=2  # Higher resolution
            )

            return True
        except Exception as e:
            print(f"Error saving diagram: {e}")
            return False

def generate_career_path(output_dir='static/visualizations'):
    """Create and save the career path visualization."""
    visualizer = CareerPathVisualizer()
    visualizer.save_diagram(os.path.join(output_dir, 'career_path.html'))

def main():
    """Create and save the career path visualization."""
    visualizer = CareerPathVisualizer()
    visualizer.save_diagram()

if __name__ == '__main__':
    main()
