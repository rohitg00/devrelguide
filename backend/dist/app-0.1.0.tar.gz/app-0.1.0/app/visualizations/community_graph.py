import networkx as nx
import plotly.graph_objects as go
import json
import numpy as np
import os

class CommunityGraphVisualizer:
    """Creates an interactive network graph visualization of DevRel community connections."""

    def __init__(self):
        self.G = nx.Graph()
        self.communities = {
            'DevRel Team': ['Developer Advocates', 'Community Managers', 'Technical Writers'],
            'Developer Community': ['Open Source Contributors', 'Enterprise Developers', 'Startup Developers'],
            'Content': ['Documentation', 'Tutorials', 'Blog Posts', 'Video Content'],
            'Events': ['Conferences', 'Meetups', 'Workshops', 'Hackathons'],
            'Platforms': ['GitHub', 'Stack Overflow', 'Discord', 'Twitter']
        }
        self._build_graph()

    def _build_graph(self):
        """Build the network graph structure."""
        # Add main community hubs
        for hub in self.communities.keys():
            self.G.add_node(hub, node_type='hub', size=30)

            # Add community members and connect to hub
            for member in self.communities[hub]:
                self.G.add_node(member, node_type='member', size=20)
                self.G.add_edge(hub, member, weight=1)

        # Add cross-connections between related nodes
        cross_connections = [
            ('Developer Advocates', 'Conferences'),
            ('Developer Advocates', 'Documentation'),
            ('Community Managers', 'Discord'),
            ('Technical Writers', 'Documentation'),
            ('Open Source Contributors', 'GitHub'),
            ('Enterprise Developers', 'Stack Overflow'),
            ('Blog Posts', 'Twitter'),
            ('Conferences', 'Twitter'),
        ]

        for source, target in cross_connections:
            self.G.add_edge(source, target, weight=0.5)

    def create_network_visualization(self):
        """Generate an interactive network visualization using Plotly."""
        # Calculate layout using Fruchterman-Reingold force-directed algorithm
        pos = nx.spring_layout(self.G, k=1, iterations=50)

        # Prepare node traces
        hub_nodes = [node for node in self.G.nodes() if self.G.nodes[node].get('node_type') == 'hub']
        member_nodes = [node for node in self.G.nodes() if self.G.nodes[node].get('node_type') == 'member']

        # Create edge trace
        edge_x = []
        edge_y = []
        for edge in self.G.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])

        edge_trace = go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=0.5, color='#888'),
            hoverinfo='none',
            mode='lines')

        # Create hub nodes trace
        hub_trace = go.Scatter(
            x=[pos[node][0] for node in hub_nodes],
            y=[pos[node][1] for node in hub_nodes],
            mode='markers+text',
            hoverinfo='text',
            text=hub_nodes,
            textposition="top center",
            marker=dict(
                size=30,
                color='rgb(66,133,244)',
                line=dict(width=2, color='white')
            ),
            name='Community Hubs'
        )

        # Create member nodes trace
        member_trace = go.Scatter(
            x=[pos[node][0] for node in member_nodes],
            y=[pos[node][1] for node in member_nodes],
            mode='markers+text',
            hoverinfo='text',
            text=member_nodes,
            textposition="top center",
            marker=dict(
                size=20,
                color='rgb(251,188,4)',
                line=dict(width=2, color='white')
            ),
            name='Community Members'
        )

        # Create figure
        fig = go.Figure(data=[edge_trace, hub_trace, member_trace])

        # Update layout
        fig.update_layout(
            title="DevRel Community Network",
            showlegend=True,
            hovermode='closest',
            margin=dict(b=20,l=5,r=5,t=40),
            annotations=[
                dict(
                    text="Interactive visualization of DevRel community connections and relationships",
                    xref="paper",
                    yref="paper",
                    x=0,
                    y=1.1,
                    showarrow=False,
                    font=dict(size=12)
                )
            ],
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            plot_bgcolor='white',
            width=1200,
            height=800
        )

        return fig

    def save_visualization(self, output_file='community_network.html'):
        """Save the network visualization to HTML and PNG files."""
        try:
            fig = self.create_network_visualization()

            # Save HTML version
            fig.write_html(output_file, include_plotlyjs=True, full_html=True)

            # Save PNG version
            png_file = os.path.splitext(output_file)[0] + '.png'
            fig.write_image(
                png_file,
                width=1200,
                height=800,
                scale=2  # Higher resolution
            )

            return True
        except Exception as e:
            print(f"Error saving visualization: {e}")
            return False

def generate_community_graph(output_dir='static/visualizations'):
    """Create and save the community network visualization."""
    visualizer = CommunityGraphVisualizer()
    visualizer.save_visualization(os.path.join(output_dir, 'community_network.html'))

def main():
    """Create and save the community network visualization."""
    visualizer = CommunityGraphVisualizer()
    visualizer.save_visualization()

if __name__ == '__main__':
    main()
