import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
from typing import List, Dict, Optional
from datetime import datetime
import logging
import json
import subprocess
import re
import os
import feedparser

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DevRelScraper:
    """Scraper for DevRel resources from various sources."""

    def __init__(self, rate_limit_delay: float = 1.0):
        """Initialize the scraper with rate limiting."""
        self.rate_limit_delay = rate_limit_delay
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.data_dir = os.path.join(self.base_dir, 'data')
        os.makedirs(self.data_dir, exist_ok=True)

    def _safe_request(self, url: str, max_retries: int = 3) -> Optional[requests.Response]:
        """Make a safe HTTP request with retries and proper headers."""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0'
        }

        for attempt in range(max_retries):
            try:
                logger.info(f"Attempting request to {url} (attempt {attempt + 1}/{max_retries})")
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code == 200:
                    logger.info(f"Successfully fetched {url}")
                    return response
                elif response.status_code == 429:  # Too Many Requests
                    wait_time = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited on {url}. Waiting {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    logger.warning(f"Request to {url} failed with status code {response.status_code}")
                    time.sleep(2 ** attempt)  # Exponential backoff
            except requests.Timeout:
                logger.warning(f"Request to {url} timed out (attempt {attempt + 1}/{max_retries})")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
            except requests.RequestException as e:
                logger.warning(f"Request to {url} failed: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)

        logger.error(f"All attempts to fetch {url} failed")
        return None

    def get_github_devrel_programs(self) -> List[Dict]:
        """Get DevRel programs and resources from GitHub."""
        resources = []
        search_terms = [
            'awesome+devrel', 'awesome+"developer+relations"',
            'devrel+resources', 'devrel+guide',
            '"developer+relations"+handbook',
            '"developer+advocacy"+guide',
            'devrel+community+building',
            'developer+experience+framework'
        ]

        # First, search for general DevRel resources
        for term in search_terms:
            try:
                url = f'https://api.github.com/search/repositories?q={term}+in:name,description,readme&sort=stars&order=desc'
                response = self._safe_request(url)

                if response and response.ok:
                    data = response.json()
                    repos = data.get('items', [])
                    total_count = data.get('total_count', 0)
                    logging.info(f"Found {total_count} repositories for term: {term}")

                    for repo in repos[:10]:  # Get top 10 repos per search term
                        # Validate repository data
                        if not all(key in repo for key in ['name', 'html_url', 'description', 'stargazers_count']):
                            logging.warning(f"Skipping repository with incomplete data: {repo.get('name', 'unknown')}")
                            continue

                        # Check for minimum stars to ensure quality
                        if repo['stargazers_count'] < 5:
                            continue

                        resources.append({
                            'name': repo['name'],
                            'url': repo['html_url'],
                            'description': repo['description'] or '',
                            'stars': repo['stargazers_count'],
                            'source': 'github',
                            'search_term': term,
                            'type': 'repository',
                            'topics': repo.get('topics', []),
                            'last_updated': repo.get('updated_at', ''),
                            'language': repo.get('language', '')
                        })

                else:
                    logging.warning(f"Failed to fetch GitHub results for term {term}")

                # Respect GitHub API rate limits
                time.sleep(2)
            except Exception as e:
                logging.error(f"Error fetching GitHub data for term {term}: {str(e)}")
                if 'rate limit' in str(e).lower():
                    logging.warning("Rate limit reached, waiting 60 seconds...")
                    time.sleep(60)
                continue

        # Remove duplicates while preserving order
        seen = set()
        unique_resources = []
        for resource in resources:
            if resource['url'] not in seen:
                seen.add(resource['url'])
                unique_resources.append(resource)

        logging.info(f"Found {len(unique_resources)} unique DevRel resources on GitHub")
        return unique_resources

    def get_devrel_blog_posts(self) -> List[Dict]:
        """Get blog posts from various DevRel sources using RSS/Atom feeds."""
        blog_posts = []
        logging.info("Starting blog post collection")

        # DevRel.net RSS feed
        logging.info("Fetching DevRel.net RSS feed")
        try:
            feed = feedparser.parse('https://devrel.net/feed')
            if feed.entries:
                logging.info(f"Found {len(feed.entries)} posts from DevRel.net")
                for entry in feed.entries[:20]:  # Get latest 20 posts
                    blog_posts.append({
                        'title': entry.title,
                        'url': entry.link,
                        'source': 'devrel.net',
                        'published_date': entry.published if hasattr(entry, 'published') else '',
                        'excerpt': entry.summary if hasattr(entry, 'summary') else '',
                        'type': 'blog_post'
                    })
            else:
                logging.warning("No entries found in DevRel.net RSS feed")
        except Exception as e:
            logging.error(f"Error fetching DevRel.net RSS: {str(e)}")

        # Mary Thengvall's blog - try multiple feed URLs
        logging.info("Fetching Mary Thengvall's blog feed")
        feed_urls = [
            'https://www.marythengvall.com/blog?format=rss',
            'https://www.marythengvall.com/blog?format=atom',
            'https://www.marythengvall.com/feed',
            'https://www.marythengvall.com/rss.xml'
        ]

        for feed_url in feed_urls:
            try:
                feed = feedparser.parse(feed_url)
                if feed.entries:
                    logging.info(f"Found {len(feed.entries)} posts from Mary Thengvall's blog at {feed_url}")
                    for entry in feed.entries[:20]:
                        blog_posts.append({
                            'title': entry.title,
                            'url': entry.link,
                            'source': 'marythengvall.com',
                            'published_date': entry.published if hasattr(entry, 'published') else '',
                            'excerpt': entry.summary if hasattr(entry, 'summary') else '',
                            'type': 'blog_post'
                        })
                    break  # Found working feed, no need to try others
                else:
                    logging.warning(f"No entries found in feed: {feed_url}")
            except Exception as e:
                logging.warning(f"Error fetching feed {feed_url}: {str(e)}")

        # Developer Relations blog - try multiple feed URLs
        logging.info("Fetching Developer Relations blog feed")
        feed_urls = [
            'https://developerrelations.com/feed',
            'https://developerrelations.com/rss',
            'https://developerrelations.com/atom',
            'https://developerrelations.com/rss.xml'
        ]

        for feed_url in feed_urls:
            try:
                feed = feedparser.parse(feed_url)
                if feed.entries:
                    logging.info(f"Found {len(feed.entries)} posts from Developer Relations blog at {feed_url}")
                    for entry in feed.entries[:20]:
                        blog_posts.append({
                            'title': entry.title,
                            'url': entry.link,
                            'source': 'developerrelations.com',
                            'published_date': entry.published if hasattr(entry, 'published') else '',
                            'excerpt': entry.summary if hasattr(entry, 'summary') else '',
                            'type': 'blog_post'
                        })
                    break  # Found working feed, no need to try others
                else:
                    logging.warning(f"No entries found in feed: {feed_url}")
            except Exception as e:
                logging.warning(f"Error fetching feed {feed_url}: {str(e)}")

        logging.info(f"Completed blog post collection. Total posts found: {len(blog_posts)}")
        return blog_posts

    def get_devrel_job_listings(self, timeout: int = 30) -> List[Dict]:
        """Get DevRel job listings from various sources with timeout."""
        job_listings = []
        logging.info("Starting job listings collection")

        # LinkedIn jobs search
        search_terms = [
            'developer relations',
            'devrel',
            'developer advocate',
            'developer advocacy',
            'technical evangelist'
        ]

        start_time = time.time()
        for term in search_terms:
            # Check if we've exceeded the global timeout
            if time.time() - start_time > timeout:
                logger.warning(f"Job listings search exceeded timeout of {timeout} seconds")
                break

            try:
                logger.info(f"Searching LinkedIn jobs for term: {term}")
                url = f'https://www.linkedin.com/jobs/search?keywords={term.replace(" ", "%20")}&f_TPR=r604800'

                # Use a shorter timeout for individual requests
                response = requests.get(
                    url,
                    headers=self._safe_request("").request.headers if hasattr(self, '_last_response') else {},
                    timeout=5
                )

                if response and response.ok:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    jobs = soup.find_all('div', {'class': 'base-card'})
                    logger.info(f"Found {len(jobs)} jobs for term '{term}'")

                    for job in jobs:
                        try:
                            title_elem = job.find('h3', {'class': 'base-search-card__title'})
                            company_elem = job.find('h4', {'class': 'base-search-card__subtitle'})
                            location_elem = job.find('span', {'class': 'job-search-card__location'})
                            link_elem = job.find('a', {'class': 'base-card__full-link'})

                            if title_elem and company_elem and location_elem and link_elem:
                                job_listings.append({
                                    'title': title_elem.text.strip(),
                                    'company': company_elem.text.strip(),
                                    'location': location_elem.text.strip(),
                                    'url': link_elem['href'],
                                    'source': 'linkedin',
                                    'search_term': term,
                                    'type': 'job_listing',
                                    'date_found': datetime.now().isoformat()
                                })
                        except Exception as e:
                            logger.warning(f"Error parsing job listing: {str(e)}")
                            continue

                time.sleep(self.rate_limit_delay)  # Respect rate limits
            except (requests.Timeout, requests.RequestException) as e:
                logger.error(f"Error fetching LinkedIn jobs for term {term}: {str(e)}")
                continue

        # If we didn't find any jobs, return an empty list rather than hanging
        if not job_listings:
            logger.warning("No job listings found from any source")
            return []

        logger.info(f"Found {len(job_listings)} DevRel job listings")
        return job_listings

    def scrape_all(self) -> bool:
        """Run all scraping operations and save results."""
        logging.info("Starting scraping process...")

        try:
            # Get data from all sources
            github_programs = self.get_github_devrel_programs()
            blog_posts = self.get_devrel_blog_posts()
            job_listings = self.get_devrel_job_listings()

            # Save all scraped data
            resources = {
                'github_programs': github_programs,
                'blog_posts': blog_posts,
                'job_listings': job_listings,
                'last_updated': datetime.now().isoformat()
            }

            # Save to JSON file
            with open(os.path.join(self.data_dir, 'devrel_resources.json'), 'w') as f:
                json.dump(resources, f, indent=2)

            logging.info(f"Scraped {len(github_programs)} DevRel programs on GitHub")
            logging.info(f"Scraped {len(blog_posts)} blog posts")
            logging.info(f"Scraped {len(job_listings)} job listings")
            logging.info(f"Scraped {len(github_programs) + len(blog_posts) + len(job_listings)} resources in total")

            return True
        except Exception as e:
            logging.error(f"Error during scraping: {str(e)}")
            return False

def main():
    """Main function to run the scraper and save results."""
    scraper = DevRelScraper(rate_limit_delay=1.0)
    success = scraper.scrape_all()

    if success:
        logger.info("Scraping completed successfully")
    else:
        logger.error("Scraping encountered errors")

if __name__ == '__main__':
    main()
