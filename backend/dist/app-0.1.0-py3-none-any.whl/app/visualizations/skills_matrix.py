import plotly.graph_objects as go
import numpy as np
import pandas as pd
import os

class SkillsMatrixVisualizer:
    """Creates an interactive skills matrix visualization for DevRel roles."""

    def __init__(self):
        self.roles = [
            'Junior Developer Advocate',
            'Senior Developer Advocate',
            'Technical Community Manager',
            'DevRel Program Manager',
            'Head of Developer Relations'
        ]

        self.skill_categories = {
            'Technical': [
                'Programming',
                'API Design',
                'Documentation',
                'Technical Writing',
                'System Architecture'
            ],
            'Communication': [
                'Public Speaking',
                'Technical Presentations',
                'Blog Writing',
                'Social Media',
                'Workshop Facilitation'
            ],
            'Community': [
                'Community Building',
                'Event Management',
                'Developer Support',
                'Conflict Resolution',
                'Mentoring'
            ],
            'Business': [
                'Strategy Development',
                'Metrics Analysis',
                'Stakeholder Management',
                'Budget Planning',
                'Program Management'
            ]
        }

        # Generate sample skill levels (0-4) for each role and skill
        self.skill_matrix = self._generate_skill_matrix()

    def _generate_skill_matrix(self):
        """Generate a realistic skill matrix based on role seniority."""
        all_skills = []
        for category, skills in self.skill_categories.items():
            all_skills.extend([(category, skill) for skill in skills])

        matrix = {}
        for role in self.roles:
            matrix[role] = {}
            seniority = self.roles.index(role)  # Higher index = more senior

            for category, skill in all_skills:
                # Base skill level depends on seniority
                base_level = min(4, max(1, seniority + 1))

                # Adjust based on role and category
                if 'Head' in role:
                    if category in ['Business', 'Community']:
                        base_level = 4
                elif 'Program Manager' in role:
                    if category == 'Business':
                        base_level = 4
                elif 'Community Manager' in role:
                    if category == 'Community':
                        base_level = 4

                # Add some randomness but ensure it stays within bounds
                variation = np.random.randint(-1, 2)
                skill_level = max(1, min(4, base_level + variation))
                matrix[role][f"{category}: {skill}"] = skill_level

        return matrix

    def create_skills_matrix(self):
        """Generate an interactive skills matrix visualization."""
        # Prepare data for heatmap
        skills = []
        for category, category_skills in self.skill_categories.items():
            skills.extend([f"{category}: {skill}" for skill in category_skills])

        z_data = []
        for role in self.roles:
            row = [self.skill_matrix[role][skill] for skill in skills]
            z_data.append(row)

        # Create custom text for hover information
        hover_text = []
        for i, role in enumerate(self.roles):
            hover_row = []
            for j, skill in enumerate(skills):
                level = z_data[i][j]
                level_text = ['Basic', 'Intermediate', 'Proficient', 'Advanced', 'Expert'][level-1]
                hover_row.append(f"Role: {role}<br>Skill: {skill}<br>Level: {level_text}")
            hover_text.append(hover_row)

        # Create heatmap
        fig = go.Figure(data=go.Heatmap(
            z=z_data,
            x=skills,
            y=self.roles,
            hoverongaps=False,
            text=hover_text,
            hoverinfo='text',
            colorscale=[
                [0, '#f7fbff'],
                [0.25, '#c6dbef'],
                [0.5, '#6baed6'],
                [0.75, '#3182bd'],
                [1, '#08519c']
            ],
            showscale=True,
            colorbar=dict(
                title='Skill Level',
                ticktext=['Basic', 'Intermediate', 'Proficient', 'Advanced', 'Expert'],
                tickvals=[1, 2, 3, 4, 5],
            )
        ))

        # Update layout
        fig.update_layout(
            title='DevRel Skills Matrix',
            xaxis=dict(
                tickangle=45,
                title='Skills by Category',
                tickfont=dict(size=10),
            ),
            yaxis=dict(
                title='Roles',
                tickfont=dict(size=12),
            ),
            height=800,
            width=1400,
            margin=dict(l=150, r=50, t=50, b=150),
            annotations=[
                dict(
                    text="Interactive DevRel Skills Matrix showing required competency levels across different roles",
                    xref="paper",
                    yref="paper",
                    x=0,
                    y=1.1,
                    showarrow=False,
                    font=dict(size=12)
                )
            ]
        )

        return fig

    def save_matrix(self, output_file='skills_matrix.html'):
        """Save the skills matrix visualization to HTML and PNG files."""
        try:
            fig = self.create_skills_matrix()

            # Save HTML version
            fig.write_html(output_file, include_plotlyjs=True, full_html=True)

            # Save PNG version
            png_file = os.path.splitext(output_file)[0] + '.png'
            fig.write_image(
                png_file,
                width=1400,
                height=800,
                scale=2  # Higher resolution
            )

            return True
        except Exception as e:
            print(f"Error saving matrix: {e}")
            return False

def generate_skills_matrix(output_dir='static/visualizations'):
    """Create and save the skills matrix visualization."""
    visualizer = SkillsMatrixVisualizer()
    visualizer.save_matrix(os.path.join(output_dir, 'skills_matrix.html'))

def main():
    """Create and save the skills matrix visualization."""
    visualizer = SkillsMatrixVisualizer()
    visualizer.save_matrix()

if __name__ == '__main__':
    main()
