from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import sys
import os
import asyncio
from pathlib import Path
from typing import Dict
from pydantic import BaseModel
import logging
from concurrent.futures import ThreadPoolExecutor, TimeoutError
import functools

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import script functions
from .scripts.update_resources import update_resources
from .scripts.analyze_data import analyze_data
from .scripts.verify_links import verify_links

app = FastAPI(title="DevRel Whitepaper API")

# Disable CORS. Do not remove this for full-stack development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Set up required directories
static_path = Path(__file__).parent / "static"
data_path = Path(__file__).parent / "data"
static_path.mkdir(exist_ok=True)
data_path.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_path)), name="static")

class ScriptResponse(BaseModel):
    status: str
    message: str
    data: Dict | None = None

@app.get("/healthz")
async def healthz():
    return {"status": "ok"}

@app.get("/api/content")
async def get_content():
    try:
        readme_path = Path(__file__).parent / "README.md"
        if not readme_path.exists():
            raise HTTPException(status_code=404, detail="Content file not found")

        with open(readme_path, "r", encoding="utf-8") as f:
            content = f.read()
            # Update image paths to use static URL
            content = content.replace('](', '](/static/')
        return JSONResponse(content={"content": content})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def run_with_timeout(func, timeout):
    """Run a function with a timeout using ThreadPoolExecutor."""
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(func)
        try:
            return future.result(timeout=timeout)
        except TimeoutError:
            future.cancel()
            raise TimeoutError(f"Operation timed out after {timeout} seconds")

@app.post("/api/update-resources")
async def run_update_resources() -> ScriptResponse:
    """Update DevRel resources with proper timeout handling."""
    try:
        logger.info("Starting resource update endpoint...")

        # Run update_resources with a timeout using the helper function
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                functools.partial(run_with_timeout, update_resources, 60)
            )
            logger.info(f"Update resources completed successfully: {result}")

            return ScriptResponse(
                status=result["status"],
                message=result["message"],
                data=result["data"]
            )

        except TimeoutError as e:
            logger.error(f"Update resources timed out: {str(e)}")
            raise HTTPException(
                status_code=504,
                detail="Resource update timed out after 60 seconds"
            )

    except Exception as e:
        error_msg = f"Error updating resources: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)

@app.post("/api/analyze-data")
async def run_analyze_data() -> ScriptResponse:
    try:
        result = analyze_data()
        return ScriptResponse(
            status=result["status"],
            message=result["message"],
            data=result["data"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/verify-links")
async def run_verify_links() -> ScriptResponse:
    try:
        result = verify_links()
        return ScriptResponse(
            status=result["status"],
            message=result["message"],
            data=result["data"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
